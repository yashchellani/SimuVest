import { Component, OnInit } from '@angular/core';
import { StocksService } from '../stocks.service';
import { AuthService } from '../auth.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-stocks',
  templateUrl: './stocks.component.html',
  styleUrls: ['./stocks.component.css']
})
export class StocksComponent implements OnInit {
  companyDetails:any[]
  stockPrices:any[]
  disabled = false;

  constructor(private stocks:StocksService, private auth: AuthService, private router:Router) { }

  ngOnInit() {
    if (!this.auth.loggedIn){
      this.router.navigateByUrl("/Login")
      return
      
    }
    this.getCompanyDetails()
    this.getStockPrices()
  }

  getCompanyDetails(){
    this.stocks.getCompanyDetails().subscribe(res => {
      console.log(res)
      this.companyDetails = res
    })
  }

  getStockPrices(){
     this.stocks.getStockPrices().subscribe(res => {
        console.log(res)
    })
  }
  
  addToIndex(index:string){
    var r = confirm("Are you sure you want to add this into your index?");
    if (r == true) {
      // txt = "You pressed OK!";
      this.disabled = true;
      this.auth.updateIndex(index).subscribe(res =>{
        this.disabled = false;
      })
    } 
  }
}
