import { Component, OnInit } from '@angular/core';

import {AuthService} from '../auth.service';
import {Router} from "@angular/router"

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  indexList:any[]
  constructor(public router:Router, private auth:AuthService) { }

  ngOnInit() {
    if (!this.auth.loggedIn){
      this.router.navigateByUrl("/Login")
    }

    this.auth.getIndex().subscribe(res => {
      console.log(res)
      this.indexList = res[0].stocksList;
      console.log(this.indexList)
    })
  }

  getRandomInt(test:any) {
    // min = Math.ceil(min);
    // max = Math.floor(max);
    return  Math.floor(Math.random() * 50) + 50;
}
}
