import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {AuthService} from '../auth.service';

import { Auth } from 'aws-amplify';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  hide = true;
  error :string
  constructor(private router: Router, private auth:AuthService) { }

  ngOnInit() {
    if(this.auth.loggedIn){
      this.router.navigateByUrl("/Dashboard")
    }
  }

  async login() {
    var signin = await this.signIn();
    if (!signin){
      return
    }
    this.auth.loggedIn = true;
    this.auth.email = (<HTMLInputElement>document.getElementById("input-email")).value;
    this.router.navigateByUrl("Dashboard")
  }


  async signIn() {
    try {
      var email  = (<HTMLInputElement>document.getElementById("input-email")).value
      var pw  = (<HTMLInputElement>document.getElementById("input-pw")).value
      const user = await Auth.signIn(email, pw);
      console.log(user)
      return true
    } catch (error) {
      console.log('error signing in', error);
      this.error = error.message
      return false
    }
  }

}
