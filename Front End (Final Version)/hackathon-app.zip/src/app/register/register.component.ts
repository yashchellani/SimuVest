import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatStepper } from '@angular/material/stepper';
import { Auth } from 'aws-amplify';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {AuthService} from '../auth.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  isLinear = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  hide = true
  hide2 = true
  age = []
  preferredIndustry = ["Technology", "Real Estate", "Finance"]
  purposeOfInvestment = ["Build wealth", "Retirement", "Reach financial goals", "Start business", "Support others"]
  selectedIndustries = []
  desktop = true
  error :string;

  constructor(private formBuilder: FormBuilder,private router: Router, private auth:AuthService) { }

  ngOnInit() {
    if(this.auth.loggedIn){
      this.router.navigateByUrl("/Dashboard")
    }
    if (window.innerWidth < 700) {
      this.desktop = false

    }
    this.firstFormGroup = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      name: ['', Validators.required],
      pwSet: this.formBuilder.group({
        pw: ['', [Validators.required, Validators.minLength(8)]],
        cfmPw: ['', [Validators.required]]
      }, { validator: this.passwordMatchValidator }),
    });
    this.secondFormGroup = this.formBuilder.group({
      secondCtrl: ['', Validators.required]
    });

    for (var i = 12; i < 120; i++) {
      this.age.push(i + 1)
    }
  }

  passwordMatchValidator(myForm: FormGroup) {

    var userpassword = myForm.controls.pw.value;
    var confirmpassword = myForm.controls.cfmPw.value;

    if (!(userpassword === confirmpassword)) return { 'notmatch': true };
    return null;
  }


  async register(stepper: MatStepper) {
    var signup = await this.signUp();
    if (!signup) {
      return
    }
    this.auth.createIndex(this.firstFormGroup.value.email).subscribe(res => console.log(res))
    stepper.next();
  }

  saveProfile(stepper: MatStepper) {
    stepper.next()
  }

  selectIndustry(i: number, industry: string) {

    if (this.selectedIndustries.includes(industry)) {
      this.selectedIndustries.splice(this.selectedIndustries.indexOf(industry), 1)
      document.getElementById("preferred-industry-" + i).classList.remove("active")
    }
    else {
      this.selectedIndustries.push(industry)
      document.getElementById("preferred-industry-" + i).classList.add("active")
    }
    console.log(this.selectedIndustries)
  }

  async signUp() {
    var username = this.firstFormGroup.value.email
    var password = this.firstFormGroup.value.pwSet.pw
    try {
      const { user } = await Auth.signUp({
        username: username,
        password: password!,
        attributes: {
          email: username,          // optional
          // other custom attributes 
        }
      });
      console.log(user);
      return true
    } catch (error) {
      console.log('error signing up:', error);
      this.error = error.message
      console.log(error.message)
      console.log(this.error)
      return false
    }
  }
}
