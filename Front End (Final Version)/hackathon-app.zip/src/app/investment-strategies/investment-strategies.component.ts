import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-investment-strategies',
  templateUrl: './investment-strategies.component.html',
  styleUrls: ['./investment-strategies.component.css']
})
export class InvestmentStrategiesComponent implements OnInit {

  constructor(private auth:AuthService, private router:Router) { }

  ngOnInit() {
    if (!this.auth.loggedIn){
      this.router.navigateByUrl("/Login")
    }
  }

}
