import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StocksService {

  constructor(private http:HttpClient) { }

  getCompanyDetails(){
    return this.http.get<any[]>("/api/getCompanyDetails")
  }

  getStockPrices(){
    return this.http.get<any[]>("/api/getStockPrices")
  }
  

}
